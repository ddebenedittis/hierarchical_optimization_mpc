import copy
import os
from datetime import datetime
from itertools import combinations

import matplotlib.pyplot as plt
import networkx as nx
import numpy as np
import progressbar
from ament_index_python.packages import get_package_share_directory
from scipy.spatial.distance import pdist

import distributed_ho_mpc.scenarios.formation_obstacle_omni.settings as st
from distributed_ho_mpc.scenarios.formation_obstacle_omni.node import Node
from hierarchical_optimization_mpc.utils.disp_het_multi_rob import (
    MultiRobotArtistFlags,
    display_animation,
    plot_distances,
    save_snapshots,
)
from hierarchical_optimization_mpc.utils.robot_models import (
    get_omnidirectional_model,
    get_unicycle_model,
)


def main():
    b = progressbar.ProgressBar(maxval=st.n_steps)
    b.start()
    model = {
        'unicycle': get_unicycle_model(st.dt),
        'omnidirectional': get_omnidirectional_model(st.dt),
    }

    def agents_distance(state, pairwise_distances):
        """
        Plot the distance between the agents at each time step
        """
        positions_over_time = np.array(state)
        distances = pdist(positions_over_time, metric='euclidean')  # shape: (num_pairs,)
        for i, d in enumerate(distances):
            pairwise_distances[i].append(d)
        return pairwise_distances

    # =========================================================================== #
    #                                TASK SCHEDULER                               #
    # =========================================================================== #

    goals = [
        np.array([0, 0]),
        np.array([3.53, 3.53]),
        np.array([-2.53, 3.53]),
        # np.array([-3.5, -2])
        # np.array([-5, -5]),
        # np.array([-5, 5]),
        # np.array([5, 5])
    ]

    system_tasks = {
        'agent_0': [
            {'prio': 1, 'name': 'input_limits'},
            {'prio': 2, 'name': 'input_smooth'},
            {'prio': 2, 'name':"obstacle_avoidance"},
            {'prio': 3, 'name': 'vel_ref'},
            {'prio': 4, 'name': 'formation', 'agents': [[0, 8]], 'distance': 5},
            {'prio': 4, 'name': 'formation', 'agents': [[0, 1]], 'distance': 3.84},
            {'prio': 4, 'name': 'formation', 'agents': [[0, 7]], 'distance': 3.84},
        ],
        'agent_1': [
            {'prio': 1, 'name': 'input_limits'},
            {'prio': 2, 'name': 'input_smooth'},
            {'prio': 2, 'name': 'obstacle_avoidance'},
            # {'prio':3, 'name':"position", 'goal': goals[1],'goal_index':1},
            {'prio': 3, 'name': 'vel_ref'},
            {'prio': 4, 'name': 'formation', 'agents': [[0, 1]], 'distance': 3.84},
            {'prio': 4, 'name': 'formation', 'agents': [[1, 2]], 'distance': 3.84},
            {'prio': 4, 'name': 'formation', 'agents': [[1, 8]], 'distance': 5},
            # {'prio'34, 'name':"formation", 'agents': [[1,5]], 'distance': 10},
        ],
        'agent_2': [
            {'prio': 1, 'name': 'input_limits'},
            {'prio': 2, 'name': 'input_smooth'},
            {'prio': 2, 'name':"obstacle_avoidance"},
            {'prio': 3, 'name': 'vel_ref'},
            {'prio': 4, 'name': 'formation', 'agents': [[2, 8]], 'distance': 5},
            {'prio': 4, 'name': 'formation', 'agents': [[1, 2]], 'distance': 3.84},
            {'prio': 4, 'name': 'formation', 'agents': [[2, 3]], 'distance': 3.84},
        ],
        'agent_3': [
            {'prio': 1, 'name': 'input_limits'},
            {'prio': 2, 'name': 'input_smooth'},
            {'prio': 2, 'name':"obstacle_avoidance"},
            {'prio': 3, 'name': 'vel_ref'},
            {'prio': 4, 'name': 'formation', 'agents': [[2, 3]], 'distance': 3.84},
            {'prio': 4, 'name': 'formation', 'agents': [[3, 4]], 'distance': 3.84},
            {'prio': 4, 'name': 'formation', 'agents': [[3, 8]], 'distance': 5},
            # {'prio'34, 'name':"formation", 'agents': [[1,3]], 'distance': 7.07},
            # {'prio'34, 'name':"formation", 'agents': [[7,3]], 'distance': 10},
            # {'prio':3, 'name':"position", 'goal': goals[1],'goal_index':1},
        ],
        'agent_4': [
            {'prio': 1, 'name': 'input_limits'},
            {'prio': 2, 'name': 'input_smooth'},
            {'prio': 2, 'name':"obstacle_avoidance"},
            {'prio': 3, 'name': 'vel_ref'},
            {'prio': 4, 'name': 'formation', 'agents': [[8, 4]], 'distance': 5},
            {'prio': 4, 'name': 'formation', 'agents': [[3, 4]], 'distance': 3.84},
            {'prio': 4, 'name': 'formation', 'agents': [[4, 5]], 'distance': 3.84},
        ],
        'agent_5': [
            {'prio': 1, 'name': 'input_limits'},
            {'prio': 2, 'name': 'input_smooth'},
            {'prio': 2, 'name': 'obstacle_avoidance'},
            {'prio': 3, 'name': 'vel_ref'},
            {'prio': 4, 'name': 'formation', 'agents': [[4, 5]], 'distance': 3.84},
            {'prio': 4, 'name': 'formation', 'agents': [[5, 6]], 'distance': 3.84},
            {'prio': 4, 'name': 'formation', 'agents': [[5, 8]], 'distance': 5},
        ],
        'agent_6': [
            {'prio': 1, 'name': 'input_limits'},
            {'prio': 2, 'name': 'input_smooth'},
            {'prio': 2, 'name': 'obstacle_avoidance'},
            {'prio': 3, 'name': 'vel_ref'},
            {'prio': 4, 'name': 'formation', 'agents': [[6, 8]], 'distance': 5},
            {'prio': 4, 'name': 'formation', 'agents': [[5, 6]], 'distance': 3.84},
            {'prio': 4, 'name': 'formation', 'agents': [[6, 7]], 'distance': 3.84},
        ],
        'agent_7': [
            {'prio': 1, 'name': 'input_limits'},
            {'prio': 2, 'name': 'input_smooth'},
            {'prio': 3, 'name': 'vel_ref'},
            {'prio': 2, 'name':"obstacle_avoidance"},
            # {'prio':3, 'name':"position", 'goal': goals[2],'goal_index':2},
            {'prio': 4, 'name': 'formation', 'agents': [[6, 7]], 'distance': 3.84},
            {'prio': 4, 'name': 'formation', 'agents': [[0, 7]], 'distance': 3.84},
            {'prio': 4, 'name': 'formation', 'agents': [[8, 7]], 'distance': 5},
            # {'prio'34, 'name':"formation", 'agents': [[7,5]], 'distance': 7.07},
            # {'prio'34, 'name':"formation", 'agents': [[7,3]], 'distance': 10},
            # {'prio':3, 'name':"position", 'goal': goals[1],'goal_index':1},
        ],
        'agent_8': [
            {'prio': 1, 'name': 'input_limits'},
            {'prio': 2, 'name': 'input_smooth'},
            {'prio': 2, 'name': 'obstacle_avoidance'},
            {'prio': 3, 'name': 'vel_ref'},
            # {'prio': 3, 'name': 'vel_ref'},
            {'prio': 4, 'name': 'formation', 'agents': [[0, 8]], 'distance': 5},
            {'prio': 4, 'name': 'formation', 'agents': [[1, 8]], 'distance': 5},
            {'prio': 4, 'name': 'formation', 'agents': [[2, 8]], 'distance': 5},
            {'prio': 4, 'name': 'formation', 'agents': [[3, 8]], 'distance': 5},
            {'prio': 4, 'name': 'formation', 'agents': [[4, 8]], 'distance': 5},
            {'prio': 4, 'name': 'formation', 'agents': [[6, 8]], 'distance': 5},
            {'prio': 4, 'name': 'formation', 'agents': [[5, 8]], 'distance': 5},
            {'prio': 4, 'name': 'formation', 'agents': [[7, 8]], 'distance': 5},
        ],
    }
    
    '''system_tasks = {
        'agent_0': [
            {'prio': 1, 'name': 'input_limits'},
            {'prio': 2, 'name': 'input_smooth'},
            # {'prio':3, 'name':"obstacle_avoidance"},
            {'prio': 3, 'name': 'formation', 'agents': [[0, 8]], 'distance': 5},
            {'prio': 3, 'name': 'formation', 'agents': [[0, 1]], 'distance': 3.84},
            {'prio': 3, 'name': 'formation', 'agents': [[0, 7]], 'distance': 3.84},
        ],
        'agent_1': [
            {'prio': 1, 'name': 'input_limits'},
            {'prio': 2, 'name': 'input_smooth'},
            {'prio': 2, 'name': 'obstacle_avoidance'},
            # {'prio':3, 'name':"position", 'goal': goals[1],'goal_index':1},
            {'prio': 3, 'name': 'formation', 'agents': [[0, 1]], 'distance': 3.84},
            {'prio': 3, 'name': 'formation', 'agents': [[1, 2]], 'distance': 3.84},
            {'prio': 3, 'name': 'formation', 'agents': [[1, 8]], 'distance': 5},
            # {'prio':4, 'name':"formation", 'agents': [[1,5]], 'distance': 10},
        ],
        'agent_2': [
            {'prio': 1, 'name': 'input_limits'},
            {'prio': 2, 'name': 'input_smooth'},
            # {'prio':3, 'name':"obstacle_avoidance"},
            {'prio': 3, 'name': 'formation', 'agents': [[2, 8]], 'distance': 5},
            {'prio': 3, 'name': 'formation', 'agents': [[1, 2]], 'distance': 3.84},
            {'prio': 3, 'name': 'formation', 'agents': [[2, 3]], 'distance': 3.84},
        ],
        'agent_3': [
            {'prio': 1, 'name': 'input_limits'},
            {'prio': 2, 'name': 'input_smooth'},
            # {'prio':3, 'name':"obstacle_avoidance"},
            {'prio': 3, 'name': 'formation', 'agents': [[2, 3]], 'distance': 3.84},
            {'prio': 3, 'name': 'formation', 'agents': [[3, 4]], 'distance': 3.84},
            {'prio': 3, 'name': 'formation', 'agents': [[3, 8]], 'distance': 5},
            # {'prio':4, 'name':"formation", 'agents': [[1,3]], 'distance': 7.07},
            # {'prio':4, 'name':"formation", 'agents': [[7,3]], 'distance': 10},
            # {'prio':3, 'name':"position", 'goal': goals[1],'goal_index':1},
        ],
        'agent_4': [
            {'prio': 1, 'name': 'input_limits'},
            {'prio': 2, 'name': 'input_smooth'},
            # {'prio':3, 'name':"obstacle_avoidance"},
            {'prio': 3, 'name': 'formation', 'agents': [[8, 4]], 'distance': 5},
            {'prio': 3, 'name': 'formation', 'agents': [[3, 4]], 'distance': 3.84},
            {'prio': 3, 'name': 'formation', 'agents': [[4, 5]], 'distance': 3.84},
        ],
        'agent_5': [
            {'prio': 1, 'name': 'input_limits'},
            {'prio': 2, 'name': 'input_smooth'},
            {'prio': 2, 'name': 'obstacle_avoidance'},
            {'prio': 3, 'name': 'formation', 'agents': [[4, 5]], 'distance': 3.84},
            {'prio': 3, 'name': 'formation', 'agents': [[5, 6]], 'distance': 3.84},
            # {'prio':4, 'name':"formation", 'agents': [[5,7]], 'distance': 7.07},
            {'prio': 3, 'name': 'formation', 'agents': [[5, 8]], 'distance': 5},
        ],
        'agent_6': [
            {'prio': 1, 'name': 'input_limits'},
            {'prio': 2, 'name': 'input_smooth'},
            {'prio': 2, 'name': 'obstacle_avoidance'},
            {'prio': 3, 'name': 'formation', 'agents': [[6, 8]], 'distance': 5},
            {'prio': 3, 'name': 'formation', 'agents': [[5, 6]], 'distance': 3.84},
            {'prio': 3, 'name': 'formation', 'agents': [[6, 7]], 'distance': 3.84},
        ],
        'agent_7': [
            {'prio': 1, 'name': 'input_limits'},
            {'prio': 2, 'name': 'input_smooth'},
            # {'prio':3, 'name':"obstacle_avoidance"},
            # {'prio':3, 'name':"position", 'goal': goals[2],'goal_index':2},
            {'prio': 3, 'name': 'formation', 'agents': [[6, 7]], 'distance': 3.84},
            {'prio': 3, 'name': 'formation', 'agents': [[0, 7]], 'distance': 3.84},
            {'prio': 3, 'name': 'formation', 'agents': [[8, 7]], 'distance': 5},
            # {'prio':4, 'name':"formation", 'agents': [[7,5]], 'distance': 7.07},
            # {'prio':4, 'name':"formation", 'agents': [[7,3]], 'distance': 10},
            # {'prio':3, 'name':"position", 'goal': goals[1],'goal_index':1},
        ],
        'agent_8': [
            {'prio': 1, 'name': 'input_limits'},
            {'prio': 2, 'name': 'input_smooth'},
            {'prio': 2, 'name': 'obstacle_avoidance'},
            {'prio': 3, 'name': 'position', 'goal': goals[0], 'goal_index': 0},
            # {'prio': 3, 'name': 'vel_ref'},
            {'prio': 4, 'name': 'formation', 'agents': [[0, 8]], 'distance': 5},
            {'prio': 4, 'name': 'formation', 'agents': [[1, 8]], 'distance': 5},
            {'prio': 4, 'name': 'formation', 'agents': [[2, 8]], 'distance': 5},
            {'prio': 4, 'name': 'formation', 'agents': [[3, 8]], 'distance': 5},
            {'prio': 4, 'name': 'formation', 'agents': [[4, 8]], 'distance': 5},
            {'prio': 4, 'name': 'formation', 'agents': [[6, 8]], 'distance': 5},
            {'prio': 4, 'name': 'formation', 'agents': [[5, 8]], 'distance': 5},
            {'prio': 4, 'name': 'formation', 'agents': [[7, 8]], 'distance': 5},
        ],
    }'''

    # ---------------------------------------------------------------------------- #
    #               Create the network and connection between agents               #
    # ---------------------------------------------------------------------------- #

    # deterministic graphs
    if st.n_nodes == 2:
        graph_matrix = np.array([[0.0, 1.0], [1.0, 0.0]])
        network_graph = nx.from_numpy_array(graph_matrix, nodelist=[0, 1])
    if st.n_nodes == 3:
        graph_matrix = np.array([[0.0, 1.0, 0.0], [1.0, 0.0, 1.0], [0.0, 1.0, 0.0]])
        network_graph = nx.from_numpy_array(graph_matrix, nodelist=[0, 1, 2])
    if st.n_nodes == 4:
        graph_matrix = np.array(
            [
                [0.0, 0.0, 0.0, 0.0],
                [0.0, 0.0, 0.0, 0.0],
                [0.0, 0.0, 0.0, 1.0],
                [0.0, 0.0, 1.0, 0.0],
            ]
        )
        network_graph = nx.from_numpy_array(graph_matrix, nodelist=[0, 1, 2, 3])
    if st.n_nodes == 5:
        graph_matrix = np.array(
            [
                [0.0, 1.0, 1.0, 0.0, 0.0],
                [1.0, 0.0, 0.0, 1.0, 1.0],
                [1.0, 0.0, 0.0, 1.0, 1.0],
                [0.0, 1.0, 1.0, 0.0, 1.0],
                [0.0, 1.0, 1.0, 1.0, 0.0],
            ]
        )
        network_graph = nx.from_numpy_array(graph_matrix, nodelist=[0, 1, 2, 3, 4])
    if st.n_nodes == 9:
        graph_matrix = np.array(
            [
                [0.0, 1.0, 0.0, 0.0, 0.0, 0.0, 0.0, 1.0, 1.0],
                [1.0, 0.0, 1.0, 0.0, 0.0, 0.0, 0.0, 0.0, 1.0],
                [0.0, 1.0, 0.0, 1.0, 0.0, 0.0, 0.0, 0.0, 1.0],
                [0.0, 0.0, 1.0, 0.0, 1.0, 0.0, 0.0, 0.0, 1.0],
                [0.0, 0.0, 0.0, 1.0, 0.0, 1.0, 0.0, 0.0, 1.0],
                [0.0, 0.0, 0.0, 0.0, 1.0, 0.0, 1.0, 0.0, 1.0],
                [0.0, 0.0, 0.0, 0.0, 0.0, 1.0, 0.0, 1.0, 1.0],
                [1.0, 0.0, 0.0, 0.0, 0.0, 0.0, 1.0, 0.0, 1.0],
                [1.0, 1.0, 1.0, 1.0, 1.0, 1.0, 1.0, 1.0, 0.0],
            ]
        )
    network_graph = nx.from_numpy_array(graph_matrix, nodelist=[0, 1, 2, 3, 4, 5, 6, 7, 8])
    # graph_matrix = np.zeros((st.n_nodes, st.n_nodes))

    # random graph 🎲
    while st.random_graph:
        network_graph = nx.gnp_random_graph(st.n_nodes, st.p)
        graph_matrix = nx.to_numpy_array(network_graph)

        test = np.linalg.matrix_power((st.I_NN + graph_matrix), st.n_nodes)

        if np.all(test > 0):
            print('the graph is connected')
            # nx.draw(network_graph)
            # plt.show()
            break
        else:
            print('the graph is NOT connected')

    # update task manifold with the neighbours tasks
    neigh_tasks = {}
    for i in range(st.n_nodes):
        id = 0
        neigh_tasks[f'agent_{i}'] = {}
        for j in graph_matrix[i]:
            if int(j) != 0:
                neigh_tasks[f'agent_{i}'][f'agent_{id}'] = copy.deepcopy(
                    system_tasks[f'agent_{id}']
                )
            id += 1

    # ----------------------------------------------------------------------------- #
    #         Create agents and initialize them based on settings and tasks        #
    # ---------------------------------------------------------------------------- #

    nodes = []  # list of agents of the system

    package_name = 'distributed_ho_mpc'
    workspace_dir = f'{get_package_share_directory(package_name)}/../../../..'
    out_dir = (
        f'{workspace_dir}/out/{datetime.now().strftime("%Y-%m-%d_%H-%M-%S")}-formation_obstacle/'
    )
    os.makedirs(out_dir, exist_ok=True)

    # Create an agents of the same type for each node of the system
    for i in range(st.n_nodes):
        node = Node(
            i,  # ID
            graph_matrix[i],  # Neighbours
            model['unicycle'],  # robot model
            st.dt,  # time step
            system_tasks[f'agent_{i}'],  # agent's tasks
            neigh_tasks[f'agent_{i}'],  # neighbours tasks
            goals,  # goals to be reached
            st.n_steps,  # max simulation steps
            out_dir=out_dir,
        )
        nodes.append(node)

        # create frameworks for the agents
        nodes[i].Tasks()
        nodes[i].MPC()

    # ---------------------------------------------------------------------------- #
    #     iterate through the nodes, transmitting datas and the receiving them     #
    # ---------------------------------------------------------------------------- #

    # DISTANCES BETWEEN AGENTS
    state = [None] * st.n_nodes  # list of x for inizialization of optimization

    num_robots = st.n_nodes
    num_pairs = int(num_robots * (num_robots - 1) / 2)

    # Initialize one list per robot pair
    pairwise_distances = [[] for _ in range(num_pairs)]

    """for j in range(st.n_nodes):
        state[j] = nodes[j].s.omni[0]  # TODO manage heterogeneous robots
    # neigh_connection(state, nodes, graph_matrix, st.communication_range)
    for j in range(st.n_nodes):
        nodes[j].reorder_s_init(state)
        nodes[j].update('2')  # Update primal solution and state evolution
    for j in range(st.n_nodes):
        state[j] = nodes[j].s.omni[0]  # TODO manage heterogeneous robots
        for ij in nodes[j].neigh:  # select my neighbours
            msg = nodes[j].transmit_data(ij, 'P')  # Transmit primal variable
            nodes[ij].receive_data(msg)  # neighbour receives the message
    for j in range(st.n_nodes):
        nodes[j].dual_update()  # linear update of dual problem"""

    for j in range(st.n_nodes):
        state[j] = nodes[j].s.omni[0]  # TODO manage heterogeneous robots
    for i in range(st.n_steps):
        if i == st.n_steps - 1:
            last_step = i + 1
        # for rr in range(st.inner_loop):
        for j in range(st.n_nodes):
            nodes[j].reorder_s_init(state)
            nodes[j].update('2')  # Update primal solution and state evolution
        for j in range(st.n_nodes):
            state[j] = nodes[j].s.omni[0]  # TODO manage heterogeneous robots
            # for ij in nodes[j].neigh:  # select my neighbours
            #     msg = nodes[j].transmit_data(ij, 'P')  # Transmit primal variable
            #     nodes[ij].receive_data(msg)  # neighbour receives the message
            # for j in range(st.n_nodes):
            nodes[j].dual_update()  # linear update of dual problem
        b.update(i)
    b.finish()

    if st.simulation:
        # ---------------------------------------------------------------------------- #
        #                          plot the states evolutions                          #
        # ---------------------------------------------------------------------------- #
        # handle different lenght of the states due to add/remove of nodes
        s_hist_merged = [
            sum(([node.s_history[i][0][0]] for node in nodes), [])
            for i in range(len(nodes[0].s_history))
        ]

        s_hist_merged = [[[], s_k] for s_k in s_hist_merged]

        flags = MultiRobotArtistFlags()
        flags.voronoi = False
        flags.future_trajectory = False
        # save_snapshots(
        #     s_hist_merged,
        #     None,
        #     [[7, 7, 1.95]],
        #     st.dt,
        #     [16, 26],
        #     f'{out_dir}/snapshot',
        #     x_lim=[-6, 20],
        #     y_lim=[-6, 20],
        #     flags=flags,
        # )
        # plot_distances(
        #     s_hist_merged,
        #     0.05,  # dt 012
        #     2.0,  # 0.5, #1.8,  # dmin 0.6
        #     to_obj=True,
        #     form=True,
        # )

        display_animation(
            s_hist_merged,
            s_hist_merged,
            None,
            [[5.5, 4.5, 2.0]],
            st.dt,
            st.visual_method,
            video_name=f'{out_dir}/video.mp4',
            x_lim=[-6, 20],
            y_lim=[-6, 20],
            flags=flags,
        )


if __name__ == '__main__':
    main()
